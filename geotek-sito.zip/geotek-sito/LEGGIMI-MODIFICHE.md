# Geotek — Sito revisionato: cosa è cambiato

## Da completare prima di andare online (priorità alta)
1. **P.IVA, REA e sede legale** — inseriti come placeholder "da completare" nel footer,
   in contatti.html e nei dati strutturati JSON-LD di index.html. Obbligatori per un srl.
2. **Form contatti** — non usa più `mailto:`. In `contatti.html` l'attributo `action`
   punta a un endpoint segnaposto: create un account gratuito su
   https://formspree.io oppure https://web3forms.com, generate l'endpoint e
   incollatelo al posto di `https://formspree.io/f/form-endpoint-da-configurare`.
   Il JS (js/main.js) gestisce già l'invio e i messaggi di conferma/errore.
3. **Email reale** — sostituire `info@geotekpipeline.it` con l'indirizzo effettivo.
4. **Mappa** — in contatti.html l'iframe Google Maps punta a "Italia" in generale:
   sostituire con l'embed della sede reale (Google Maps → Condividi → Incorpora mappa).
5. **Foto reali dei cantieri** — sostituire i placeholder tratteggiati nella sezione
   "Cantieri realizzati" (index.html e movimento-terra.html) con fotografie vere.
   È il singolo intervento con il maggiore impatto sulla credibilità del sito.
6. **Certificazioni** — completare la sezione "Garanzie/Documentazione verificabile"
   con i riferimenti reali (Albo Gestori Ambientali, polizza RC, ecc.), o rimuovere
   le voci non applicabili.
7. **Dominio** — tutti gli URL assoluti (canonical, Open Graph, sitemap.xml,
   robots.txt, JSON-LD) usano https://www.geotekpipeline.it/ come segnaposto:
   sostituire con il dominio reale una volta registrato/confermato.
8. **Privacy/Cookie Policy** — sono bozze di partenza: fatele rivedere da un
   consulente privacy prima della pubblicazione, in particolare se attiverete
   Google Analytics o altri strumenti di tracciamento.

## Cosa è stato aggiunto/corretto
- Fix bug HTML: `&` non escapato negli `alt` delle immagini (era `alt="... & ..."`,
  ora `&amp;`).
- Aggiunta sezione "Cantieri realizzati" (galleria progetti) in home e nella pagina
  Movimento Terra — con placeholder pronti per le foto reali.
- Aggiunta sezione "Garanzie" con certificazioni/compliance tipiche del settore.
- Aggiunta trust bar "Operiamo per" (imprese edili, GC, enti pubblici, industria).
- Form contatti funzionante via fetch/AJAX con stato di invio, invece di `mailto:`.
- Aggiunto checkbox di consenso privacy obbligatorio sul form.
- Aggiunta mappa incorporata nella pagina contatti.
- Sostituite le emoji delle icone contatti/header con icone SVG coerenti col brand.
- Aggiunto pulsante flottante WhatsApp su tutte le pagine.
- Aggiunto banner cookie minimale (localStorage, nessun tracciamento reale incluso).
- Aggiunte pagine Privacy Policy e Cookie Policy, linkate nel footer di ogni pagina.
- Aggiunti dati strutturati JSON-LD (schema.org GeneralContractor) e meta Open Graph
  per anteprime migliori su WhatsApp/LinkedIn/Google.
- Aggiunti `robots.txt` e `sitemap.xml`.
- Aggiunto skip-link e stati di focus visibili per l'accessibilità da tastiera.
- CSS/JS invariati nella struttura visiva esistente: stessa identità (antracite + oro),
  solo estesa con i nuovi componenti sopra elencati.

## Non incluso in questa revisione
- Le immagini binarie reali (logo.png, hero_construction.jpg) non erano allegate
  come file immagine, quindi non sono state rigenerate: riutilizzate i vostri file
  originali nella cartella assets/ con lo stesso nome.

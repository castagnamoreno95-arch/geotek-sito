# Guida: pubblicare e aggiornare il sito Geotek (GitHub + Vercel)

Questa guida copre tutto il percorso: dalla cartella del sito che hai già,
fino al sito online con dominio vero, più il flusso da seguire per ogni
modifica futura.

---

## Parte 1 — Creare i due account (una tantum, gratuiti)

1. **GitHub** → [github.com](https://github.com) → Sign up
2. **Vercel** → [vercel.com](https://vercel.com) → Sign up **usando "Continue with GitHub"**
   (così i due account restano collegati automaticamente, è il passaggio che
   semplifica tutto il resto)

---

## Parte 2 — Caricare il sito su GitHub

### Opzione A — Senza terminale (più semplice, consigliata)

1. Estrai lo zip del sito sul computer (ottieni una cartella `geotek-sito`
   con dentro `index.html`, `css/`, `js/`, `assets/`, ecc.)
2. Su GitHub, clicca **"New repository"** (icona `+` in alto a destra)
3. Nome repository: `geotek-sito` — puoi lasciarlo **Private** (Vercel funziona
   anche con repository privati nel piano gratuito)
4. **Non** selezionare "Add a README" — crea il repository vuoto
5. Nella pagina del repository appena creato, clicca il link
   **"uploading an existing file"**
6. Trascina dentro **tutto il contenuto** della cartella `geotek-sito`
   (i file e le sottocartelle `css`, `js`, `assets` — non la cartella
   stessa, il suo contenuto)
7. In basso, scrivi un messaggio tipo "Prima versione sito" e clicca
   **"Commit changes"**

### Opzione B — Con terminale (se hai già git installato)

```bash
cd percorso/della/cartella/geotek-sito
git init
git add .
git commit -m "Sito Geotek - versione iniziale"
git branch -M main
git remote add origin https://github.com/TUO-USERNAME/geotek-sito.git
git push -u origin main
```
(sostituisci `TUO-USERNAME` con il tuo nome utente GitHub)

---

## Parte 3 — Collegare Vercel e pubblicare

1. Vai su [vercel.com](https://vercel.com), accedi
2. **"Add New..." → "Project"**
3. Seleziona il repository `geotek-sito` dalla lista (comparirà perché è
   collegato al tuo account GitHub)
4. Impostazioni di build — **lasciale tutte come sono / vuote**:
   - Framework Preset: `Other`
   - Build Command: *(vuoto)*
   - Output Directory: *(vuoto o `./`)*
   - Non serve nessun comando: è un sito statico, non c'è nulla da "compilare"
5. Clicca **"Deploy"**
6. Dopo circa 30-60 secondi il sito è online su un indirizzo tipo
   `geotek-sito.vercel.app` — cliccalo per verificare che funzioni

---

## Parte 4 — Collegare il dominio vero (es. geotekpipeline.it)

1. Nel progetto su Vercel → **Settings → Domains → Add**
2. Scrivi il tuo dominio (es. `geotekpipeline.it`) e conferma
3. Vercel mostra uno o due **record DNS** da impostare (di solito un
   record di tipo `A` o `CNAME`)
4. Vai sul pannello del **registrar** dove avete comprato il dominio
   (es. Aruba, Register.it, SiteGround) → sezione **DNS/Nameserver**
   → aggiungi esattamente i record che Vercel ti ha mostrato
5. La propagazione DNS può richiedere da pochi minuti fino a 24-48 ore

---

## Parte 5 — Flusso per ogni modifica futura

Una volta impostato questo collegamento, ogni aggiornamento è semplice:

1. Chiedi a me la modifica (nuova foto, testo da cambiare, nuova pagina...)
2. Ti fornisco i file aggiornati
3. Carichi i file nuovi su GitHub, in uno di questi due modi:
   - **Via web**: apri il repository su github.com → trascina i file
     aggiornati nella stessa posizione → "Commit changes" (GitHub sovrascrive
     i file con lo stesso nome)
   - **Via terminale**: `git add .` → `git commit -m "aggiornamento"` → `git push`
4. **Non serve fare nient'altro**: Vercel rileva il nuovo push e ripubblica
   automaticamente il sito in circa un minuto

---

## Parte 6 — Dopo la pubblicazione: indicizzazione Google (riepilogo)

1. **Google Search Console** ([search.google.com/search-console](https://search.google.com/search-console))
   → verifica la proprietà del dominio → invia la sitemap, che si troverà a:
   `https://vostro-dominio.it/sitemap.xml` (è già pronta nel sito)
2. **Google Business Profile** ([business.google.com](https://business.google.com))
   → crealo con l'indirizzo reale della sede: per un'azienda B2B locale
   spesso conta più del posizionamento organico puro
3. Aggiornare di tanto in tanto la sezione "Novità" del sito aiuta
   l'indicizzazione nel tempo

---

## Checklist finale prima di andare online

- [ ] P.IVA, REA e indirizzo reali inseriti (footer, Contatti, Privacy Policy)
- [ ] Endpoint form contatti collegato (Formspree o Web3Forms)
- [ ] Mappa in Contatti con l'indirizzo vero
- [ ] Foto/video restanti caricati (vedi `FOTO-DA-CARICARE.md`)
- [ ] Link ai 3 PDF policy nel footer collegati, o sezione rimossa se non applicabile
- [ ] Dominio collegato e verificato su Vercel
- [ ] Sitemap inviata a Google Search Console

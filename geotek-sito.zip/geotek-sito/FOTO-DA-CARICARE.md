# Elenco foto, video e loghi da caricare — Geotek (stile Statom)

## 0. Video (novità di questa versione)

**V1 — Video hero: ✅ FATTO.** Il vostro video è stato inserito, ottimizzato per il web
(audio rimosso perché va in loop muto, dimensione ridotta da 2,4MB a 1,4MB, generato
anche in formato WebM più leggero) e un fotogramma è stato estratto come immagine di
fallback (`assets/hero_construction.jpg`). Non serve fare altro per questo.

| # | Dove va | Cosa serve | Formato |
|---|---------|-----------|---------|
| V2–V5 | Sezione "Ultimi video" (4 riquadri cliccabili) | Video più lunghi: cantiere in azione, flotta mezzi, uno scavo di fondazione, una breve intervista al referente. Possono essere caricati su YouTube (anche non in elenco pubblico) e collegati con il link, oppure file mp4 caricati sul sito. | 16:9, anche verticale se girato da smartphone (si adatta) |

Se non avete ancora questi video, il sito resta comunque completo: i 4 riquadri
"Ultimi video" restano come segnaposto cliccabili finché non collegate i link veri.


Ogni punto del sito dove serve un contenuto reale è marcato nel codice con un
commento HTML `<!-- FOTO: ... -->` subito sopra la sezione, così sai esattamente
dove va inserito. Qui sotto la lista completa, in ordine di priorità.

## 1. Foto (fotografie vere di cantiere/mezzi/squadra)

| # | Dove va | Cosa serve | Formato consigliato |
|---|---------|-----------|----------------------|
| 1 | Hero home (`assets/hero_construction.jpg`) | La foto più importante del sito: un cantiere attivo, mezzo in primo piano, luce buona (mattina/tardo pomeriggio). Orizzontale, molto larga. | 1920×1080 o più larga, JPG, <500KB |
| 2 | Fascia "In numeri" (photo-band) | Foto panoramica di cantiere con più mezzi/attività visibile — verrà scurita con un overlay quindi va bene anche più "piena" di dettagli | 1920×800 circa, orizzontale |
| 3 | Galleria "Cantieri realizzati" — riquadro grande | La foto migliore che avete di un cantiere completo o in corso avanzato | verticale o quadrata, alta risoluzione |
| 4 | Galleria — riquadro "Scavo di fondazione" | Escavatore/scavo in azione | orizzontale o quadrata |
| 5 | Galleria — riquadro "Escavatore al lavoro" | Mezzo in movimento, benna piena | orizzontale o quadrata |
| 6 | Galleria — riquadro "Trincea sottoservizi" | Scavo stretto/lineare per tubazioni/cavi | orizzontale o quadrata |
| 7 | Galleria — riquadro "Trasporto materiali" | Camion/dumper carico in movimento | orizzontale o quadrata |
| 8 | Galleria — riquadro largo "Flotta schierata" | Più mezzi visibili insieme in cantiere o in deposito | orizzontale molto larga |
| 9 | Sezione "Persone, prima dei mezzi" | Operatori con casco e gilet alta visibilità, in un momento di lavoro reale (non in posa forzata) | verticale o 4:3 |
| 10–12 | Sezione "Novità" (3 riquadri) | Foto recenti e generiche: consegna nuovo mezzo, fine cantiere, momento di squadra — anche da smartphone va benissimo | 16:10, orizzontale |
| 13 | Pagina Movimento Terra — galleria (3 riquadri) | Sbancamento, trincea, scavo di fondazione | quadrate |

**Indicazioni generali sulle foto:**
- Meglio 10 foto vere, anche scattate con lo smartphone in buona luce, che nessuna foto o immagini stock generiche.
- Evitare foto sfocate, buie o con targhe/volti di terzi non autorizzati in primo piano.
- Se possibile scattare in orizzontale per le foto principali (hero, fascia numeri, flotta) e lasciare libertà di formato per la galleria.
- Comprimete le foto (es. https://squoosh.app) prima di caricarle: pagine più veloci = miglior posizionamento Google.

## 2. Loghi (non fotografie — immagini vettoriali/trasparenti)

| # | Dove va | Cosa serve |
|---|---------|-----------|
| 14–19 | "Hanno lavorato con noi" (muro loghi clienti) | Loghi di 4-6 general contractor/imprese/clienti con cui avete lavorato, **con il loro permesso** a comparire sul sito. Se non li avete ancora, meglio nascondere la sezione finché non li avrete. |
| 20 | Badge "Albo Gestori Ambientali" | Se iscritti, il logo/attestato dell'Albo o almeno il numero di iscrizione da citare vicino al badge |
| 21 | Badge "ISO (se applicabile)" | Solo se possedete certificazioni ISO reali — altrimenti rimuovere il badge |
| 22 | Badge "Altra certificazione" | Qualsiasi altra qualificazione di settore che avete (es. SOA, patenti mezzi specifiche) |
| 23–25 | Footer "Codice Etico / Politica Qualità / Politica Sicurezza (PDF)" | Se avete o volete redigere questi documenti come PDF scaricabili — pratica comune per rassicurare general contractor ed enti pubblici, ma non obbligatoria per una srl piccola |

## Cosa fare se non avete ancora tutti i materiali

Non serve avere tutto subito. Ordine di priorità realistico:
1. **Prima le foto 1–8** (hero + galleria cantieri) — cambiano la percezione del sito più di ogni altra cosa.
2. **Poi la foto 9** (squadra/sicurezza) e i badge di certificazione che già possedete.
3. **Il muro loghi clienti** solo quando avrete il permesso esplicito di almeno 3-4 aziende — meglio ometterlo che mostrarlo vuoto o con nomi non autorizzati.
4. **La sezione "Novità"** può restare com'è e aggiornarsi nel tempo, anche con contenuti minimi.

Quando avete le foto, mandamele (o i nomi file se già le avete organizzate in cartelle)
e le inserisco direttamente al posto dei placeholder nel codice.
